﻿namespace TPO_2021
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.otwórzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edycjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cofnijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.widokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dopasujToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.xToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.podglądToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kolorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.przyciemnienieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rozjaśnienieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oziębienieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ocieplenieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rozjaśnijŚciemnijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.koloryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czarnoBiałeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.czerńBielToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czerńBielErrToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czerńBielFloydToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.kolorJednolityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kolorFloydToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.kolorówToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kolorówToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.zamknijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 426);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(185, 155);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.otwórzToolStripMenuItem,
            this.edycjaToolStripMenuItem,
            this.widokToolStripMenuItem,
            this.kolorToolStripMenuItem,
            this.koloryToolStripMenuItem,
            this.zamknijToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // otwórzToolStripMenuItem
            // 
            this.otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
            this.otwórzToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.otwórzToolStripMenuItem.Text = "Otwórz";
            this.otwórzToolStripMenuItem.Click += new System.EventHandler(this.otwórzToolStripMenuItem_Click);
            // 
            // edycjaToolStripMenuItem
            // 
            this.edycjaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cofnijToolStripMenuItem});
            this.edycjaToolStripMenuItem.Name = "edycjaToolStripMenuItem";
            this.edycjaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.edycjaToolStripMenuItem.Text = "Edycja";
            // 
            // cofnijToolStripMenuItem
            // 
            this.cofnijToolStripMenuItem.Enabled = false;
            this.cofnijToolStripMenuItem.Name = "cofnijToolStripMenuItem";
            this.cofnijToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cofnijToolStripMenuItem.Text = "Cofnij";
            this.cofnijToolStripMenuItem.Click += new System.EventHandler(this.cofnijToolStripMenuItem_Click);
            // 
            // widokToolStripMenuItem
            // 
            this.widokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dopasujToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.xToolStripMenuItem,
            this.xToolStripMenuItem1,
            this.xToolStripMenuItem2,
            this.toolStripSeparator3,
            this.podglądToolStripMenuItem});
            this.widokToolStripMenuItem.Name = "widokToolStripMenuItem";
            this.widokToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.widokToolStripMenuItem.Text = "Widok";
            // 
            // dopasujToolStripMenuItem
            // 
            this.dopasujToolStripMenuItem.Name = "dopasujToolStripMenuItem";
            this.dopasujToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.dopasujToolStripMenuItem.Text = "Dopasuj";
            this.dopasujToolStripMenuItem.Click += new System.EventHandler(this.dopasujToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem2.Text = "1  :  1";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem3.Text = "1  :  2";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem4.Text = "1  :  4";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItem5.Text = "1  :  8";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // xToolStripMenuItem
            // 
            this.xToolStripMenuItem.Name = "xToolStripMenuItem";
            this.xToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.xToolStripMenuItem.Text = "2x";
            this.xToolStripMenuItem.Click += new System.EventHandler(this.xToolStripMenuItem_Click);
            // 
            // xToolStripMenuItem1
            // 
            this.xToolStripMenuItem1.Name = "xToolStripMenuItem1";
            this.xToolStripMenuItem1.Size = new System.Drawing.Size(118, 22);
            this.xToolStripMenuItem1.Text = "4x";
            this.xToolStripMenuItem1.Click += new System.EventHandler(this.xToolStripMenuItem1_Click);
            // 
            // xToolStripMenuItem2
            // 
            this.xToolStripMenuItem2.Name = "xToolStripMenuItem2";
            this.xToolStripMenuItem2.Size = new System.Drawing.Size(118, 22);
            this.xToolStripMenuItem2.Text = "8x";
            this.xToolStripMenuItem2.Click += new System.EventHandler(this.xToolStripMenuItem2_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(115, 6);
            // 
            // podglądToolStripMenuItem
            // 
            this.podglądToolStripMenuItem.Name = "podglądToolStripMenuItem";
            this.podglądToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.podglądToolStripMenuItem.Text = "Podgląd";
            this.podglądToolStripMenuItem.Click += new System.EventHandler(this.podglądToolStripMenuItem_Click);
            // 
            // kolorToolStripMenuItem
            // 
            this.kolorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.przyciemnienieToolStripMenuItem,
            this.rozjaśnienieToolStripMenuItem,
            this.oziębienieToolStripMenuItem,
            this.ocieplenieToolStripMenuItem,
            this.rozjaśnijŚciemnijToolStripMenuItem});
            this.kolorToolStripMenuItem.Name = "kolorToolStripMenuItem";
            this.kolorToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.kolorToolStripMenuItem.Text = "Jasność";
            // 
            // przyciemnienieToolStripMenuItem
            // 
            this.przyciemnienieToolStripMenuItem.Name = "przyciemnienieToolStripMenuItem";
            this.przyciemnienieToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.przyciemnienieToolStripMenuItem.Text = "Przyciemnienie";
            this.przyciemnienieToolStripMenuItem.Click += new System.EventHandler(this.przyciemnienieToolStripMenuItem_Click);
            // 
            // rozjaśnienieToolStripMenuItem
            // 
            this.rozjaśnienieToolStripMenuItem.Name = "rozjaśnienieToolStripMenuItem";
            this.rozjaśnienieToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.rozjaśnienieToolStripMenuItem.Text = "Rozjaśnienie";
            this.rozjaśnienieToolStripMenuItem.Click += new System.EventHandler(this.rozjaśnienieToolStripMenuItem_Click);
            // 
            // oziębienieToolStripMenuItem
            // 
            this.oziębienieToolStripMenuItem.Name = "oziębienieToolStripMenuItem";
            this.oziębienieToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.oziębienieToolStripMenuItem.Text = "Oziębienie";
            this.oziębienieToolStripMenuItem.Click += new System.EventHandler(this.oziębienieToolStripMenuItem_Click);
            // 
            // ocieplenieToolStripMenuItem
            // 
            this.ocieplenieToolStripMenuItem.Name = "ocieplenieToolStripMenuItem";
            this.ocieplenieToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.ocieplenieToolStripMenuItem.Text = "Ocieplenie";
            this.ocieplenieToolStripMenuItem.Click += new System.EventHandler(this.ocieplenieToolStripMenuItem_Click);
            // 
            // rozjaśnijŚciemnijToolStripMenuItem
            // 
            this.rozjaśnijŚciemnijToolStripMenuItem.Name = "rozjaśnijŚciemnijToolStripMenuItem";
            this.rozjaśnijŚciemnijToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.rozjaśnijŚciemnijToolStripMenuItem.Text = "Rozjaśnij/Ściemnij...";
            this.rozjaśnijŚciemnijToolStripMenuItem.Click += new System.EventHandler(this.rozjaśnijŚciemnijToolStripMenuItem_Click);
            // 
            // koloryToolStripMenuItem
            // 
            this.koloryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.czarnoBiałeToolStripMenuItem1,
            this.czerńBielToolStripMenuItem,
            this.czerńBielErrToolStripMenuItem,
            this.czerńBielFloydToolStripMenuItem,
            this.toolStripSeparator1,
            this.kolorJednolityToolStripMenuItem,
            this.kolorFloydToolStripMenuItem,
            this.toolStripSeparator2,
            this.kolorówToolStripMenuItem,
            this.kolorówToolStripMenuItem1});
            this.koloryToolStripMenuItem.Name = "koloryToolStripMenuItem";
            this.koloryToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.koloryToolStripMenuItem.Text = "Kolory";
            // 
            // czarnoBiałeToolStripMenuItem1
            // 
            this.czarnoBiałeToolStripMenuItem1.Name = "czarnoBiałeToolStripMenuItem1";
            this.czarnoBiałeToolStripMenuItem1.Size = new System.Drawing.Size(162, 22);
            this.czarnoBiałeToolStripMenuItem1.Text = "Szarość";
            this.czarnoBiałeToolStripMenuItem1.Click += new System.EventHandler(this.czarnoBiałeToolStripMenuItem1_Click);
            // 
            // czerńBielToolStripMenuItem
            // 
            this.czerńBielToolStripMenuItem.Name = "czerńBielToolStripMenuItem";
            this.czerńBielToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.czerńBielToolStripMenuItem.Text = "Czerń-Biel";
            this.czerńBielToolStripMenuItem.Click += new System.EventHandler(this.czerńBielToolStripMenuItem_Click);
            // 
            // czerńBielErrToolStripMenuItem
            // 
            this.czerńBielErrToolStripMenuItem.Name = "czerńBielErrToolStripMenuItem";
            this.czerńBielErrToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.czerńBielErrToolStripMenuItem.Text = "Czerń-Biel- err";
            this.czerńBielErrToolStripMenuItem.Click += new System.EventHandler(this.czerńBielErrToolStripMenuItem_Click);
            // 
            // czerńBielFloydToolStripMenuItem
            // 
            this.czerńBielFloydToolStripMenuItem.Name = "czerńBielFloydToolStripMenuItem";
            this.czerńBielFloydToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.czerńBielFloydToolStripMenuItem.Text = "Czerń-Biel-Floyd";
            this.czerńBielFloydToolStripMenuItem.Click += new System.EventHandler(this.czerńBielFloydToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(159, 6);
            // 
            // kolorJednolityToolStripMenuItem
            // 
            this.kolorJednolityToolStripMenuItem.Name = "kolorJednolityToolStripMenuItem";
            this.kolorJednolityToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.kolorJednolityToolStripMenuItem.Text = "Kolor-Jednolity";
            this.kolorJednolityToolStripMenuItem.Click += new System.EventHandler(this.kolorJednolityToolStripMenuItem_Click);
            // 
            // kolorFloydToolStripMenuItem
            // 
            this.kolorFloydToolStripMenuItem.Name = "kolorFloydToolStripMenuItem";
            this.kolorFloydToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.kolorFloydToolStripMenuItem.Text = "Kolor-Floyd";
            this.kolorFloydToolStripMenuItem.Click += new System.EventHandler(this.kolorFloydToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(159, 6);
            // 
            // kolorówToolStripMenuItem
            // 
            this.kolorówToolStripMenuItem.Name = "kolorówToolStripMenuItem";
            this.kolorówToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.kolorówToolStripMenuItem.Text = "64 kolory";
            this.kolorówToolStripMenuItem.Click += new System.EventHandler(this.kolorówToolStripMenuItem_Click);
            // 
            // kolorówToolStripMenuItem1
            // 
            this.kolorówToolStripMenuItem1.Name = "kolorówToolStripMenuItem1";
            this.kolorówToolStripMenuItem1.Size = new System.Drawing.Size(162, 22);
            this.kolorówToolStripMenuItem1.Text = "256 kolorów";
            this.kolorówToolStripMenuItem1.Click += new System.EventHandler(this.kolorówToolStripMenuItem1_Click);
            // 
            // zamknijToolStripMenuItem
            // 
            this.zamknijToolStripMenuItem.Name = "zamknijToolStripMenuItem";
            this.zamknijToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.zamknijToolStripMenuItem.Text = "Zamknij";
            this.zamknijToolStripMenuItem.Click += new System.EventHandler(this.zamknijToolStripMenuItem_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar1.Location = new System.Drawing.Point(0, 427);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(800, 23);
            this.progressBar1.TabIndex = 2;
            this.progressBar1.Visible = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Pliki BMP (*.bmp)|*.bmp|Pliki JPEG (*.jpg)|*.jpg|Wszystkie pliki (*.*)|*.*";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem otwórzToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zamknijToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem widokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem dopasujToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem xToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem xToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem kolorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem przyciemnienieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rozjaśnienieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oziębienieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ocieplenieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rozjaśnijŚciemnijToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem koloryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czarnoBiałeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem czerńBielToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czerńBielErrToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czerńBielFloydToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kolorJednolityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kolorFloydToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kolorówToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem kolorówToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem edycjaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cofnijToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem podglądToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

