
// Mateusz Koza
// Numer albumu: 99635.


// Zadanie numer 8.

// Temat: Sortowanie przez proste wybieranie

// 1. Szukamy najmniejszego elementu 
// 2. Po znalezieniu zamieniamy go miejscami z pierwszym (chyba że ten pierwszy jest  właśnie najmniejszy)
// 3. Operację powtarzamy dla drugiego elementu itd.

public class Zad8{

    // metoda sortuje elementy tablicy przekazanej jako parametr
    public static void sortArray(int[] entry){
    // zmienna przechowująca rozmiar tablicy
    int arraySize = entry.length;

    // pętla przejścia przez wszystkie elementy tablicy
    for (int i = 0; i < arraySize; i++){
    // zakladamy, ze element na pozycji i jest najmniejszy
    int min = entry[i];
    // zapisujemy indeks tego elementu
    int index = i;

    // szukamy w pozostałej części tablicy elementu mniejszego niz min
    
    for (int j = i; j < arraySize; j++){
    // jesli jest taki, on staje się teraz elementam najmniejszym
    if(entry[j] < min) {
    min = entry[j];
    // zapisujemy jego indeks
    index=j;
    }
    }
    // zamieniamy miejscami elementy w tablicy
    // najmniejszy z aktualnym wskazywanym przez zmienną i
    entry[index] = entry[i];
    entry[i] = min;
    }
    }
    // metoda wyświetla zawartość tablicy przekazanej jako parametr na ekranie
    public static void showArray(int[] entry){
    // każdy element znajdujący się w tablicy wyświetlamy na ekranie
    for(int x : entry) System.out.print(x + " ");
    System.out.println();
    }
    public static void main(String[] args) {
    // tworzymy tablicę wypełniając ją od razu danymi
    int[] tab = {10, 45, 3, 4, 8, 25, 77};
    // wyświetlamy tablicę na ekranie
    showArray(tab);
    // sortujemy tablicę
    sortArray(tab); 
    // wyświetlamy posortowaną tablicę na ekranie
    showArray(tab);
    } // mian
    } // public class